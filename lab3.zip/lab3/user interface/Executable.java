import java.util.Scanner;
import java.util.Date;


//class definition
public class Executable {
    //main method
    public static void main (String[] args){
        Veterinary vet = new Veterinary ();
       dataV(vet);
       displayMenu(vet); 
       
    }
    
    
    //display menu
    public static void displayMenu(Veterinary vet){
        
      System.out.println (vet.toString());
      
      System.out.println ();
      
      System.out.println ("Menu");

    System.out.println ();
  
    System.out.println ("1. Add customer");
    System.out.println ("2. Add pet");
    System.out.println ("3. Display contact information");
    System.out.println ("4. Display pet by room");
    System.out.println ("5. Delete pet");
    System.out.println ("6. Inactivate customer");
    System.out.println ("7. Hospitalization");
    System.out.println ("8. Discharging pet");
    System.out.println ("9. Clinical report");
    System.out.println ("10. Calculate hospitalization cost ");
    System.out.println ("11. calculate total income");
    System.out.println ("12. Exit");
    
    Scanner in=new Scanner (System.in);
   
    int option=in.nextInt();

    switch(option){
      case 1:System.out.println("Type name");
             String name=in.nextLine();
             System.out.println("Type last name");
             String lastName=in.nextLine();

System.out.println("Type address");
String address=in.nextLine();

System.out.println("Type phone number");
int phone=in.nextInt();

in.nextLine();

System.out.println("Type ID");
int id=in.nextInt();

in.nextLine();

System.out.println("Type pet´s name");
String nameP=in.nextLine();

System.out.println("Type pet's age");
int age=in.nextInt();

in.nextLine();

System.out.println("Type pet's weight");
double weight=in.nextDouble();

in.nextLine();


System.out.println("Type pet's race");
String race=in.nextLine();

System.out.println("Type owner's name");
String ownerName=in.nextLine();

in.nextLine();

char type=in.next().charAt(0);



if(vet.validateCustomer(name,nameP)==false){
Pet pet=new Pet (nameP,type,age,weight,race,ownerName);

Customer custo=new Customer(name,address,phone,id);
vet.addCustomer(custo,pet);
 
} else{ System.out.println("usser alrady exists");}
          
   

break;

  case 2:System.out.println("Type pet's name");
String nameQ=in.nextLine();

System.out.println("Type pet's age");
int ageQ=in.nextInt();

in.nextLine();

System.out.println("Yype pet's weight");
double weightQ=in.nextDouble();

in.nextLine();

System.out.println("Type pet's race");
String raceQ=in.nextLine();

System.out.println("Type pet's owner name");

String ownerNameQ=in.nextLine();

in.nextLine();

char typeQ=in.next().charAt(0);

Pet pet=new Pet (nameQ,typeQ,ageQ,weightQ,raceQ,ownerNameQ);

 /*  Test
      Pet pet=new Pet ("sol",'p',2,2,"raceQ","holly");
      vet.addPet(pet);
 if(vet.addPet(pet)==true){System.out.println("Pet added");}
 else{System.out.println("Pet already exists");}

 Pet pet1=new Pet ("solo",'p',2,2,"raceQ","holly");
    
 if(vet.addPet(pet1)==true){System.out.println("Pet added");}
 else{System.out.println("Pet already exist");}
 
 System.out.println(vet.getCustomers().toString());
 */
break;

 case 3: System.out.println("Type Customer's name");
String nameR=in.nextLine();

in.nextLine();

System.out.println("Type pet's name");
String nameS=in.nextLine();


System.out.println(vet.contactInfo(nameR, nameS));

break;

 case 4: System.out.println("Type pet's name");

String nameT=in.nextLine();

in.nextLine();
System.out.println("Room number(s): "+vet.displayRoom(nameT));

/* test
System.out.println("Room number(s): "+vet.displayRoom("sol"));
*/

break;


 case 5: System.out.println("Type customer's name");

String nameU=in.nextLine();

in.nextLine();

System.out.println("Type pet's name");

String nameV=in.nextLine();

vet.deletePet(nameU, nameV);

/* test
vet.deletePet("holly", "solo");
System.out.println(vet.getPets().toString());

System.out.println(vet.getCustomers().get(0).getPets().toString());
*/
break;


 case 6: System.out.println("Type customer's ID");

int idV=in.nextInt();

in.nextLine();

vet.inactivateCustomer(idV);

/* test
System.out.println(vet.inactivateCustomer(00000).toString());
*/
break;


case 7: int available=vet.availability();
            
            if(available!=-1){
 
             System.out.println("Hospitalization Info");
            
             System.out.println("Type name");
             String name1=in.nextLine();
             System.out.println("Type last name");
             String lastName1=in.nextLine();

            System.out.println("Type address");
            String address1=in.nextLine();

            System.out.println("Type phone number");
            int phone1=in.nextInt();

            in.nextLine();

            System.out.println("Type ID");
            int id1=in.nextInt();

            in.nextLine();

            System.out.println("Type pet´s name");
            String nameP1=in.nextLine();

            System.out.println("Type pet's age");
            int age1=in.nextInt();

            in.nextLine();

            System.out.println("Type pet's weight");
            double weight1=in.nextDouble();

            in.nextLine();


            System.out.println("Type pet's race");
            String race1=in.nextLine();


            String ownerName1=name1+" "+lastName1;

            in.nextLine();

            char type1=in.next().charAt(0);

            Pet pet3=new Pet (nameP1,type1,age1,weight1,race1,ownerName1);

            Customer custo1=new Customer(name1,address1,phone1,id1);
            
            if(vet.validateCustomer(name1,nameP1)==false){
            vet.addCustomer(custo1,pet3);}
           
            
            System.out.println("Type symptoms");
            String symptoms=in.nextLine();
            
            System.out.println("Type diagnosis");
            String diagnosis=in.nextLine();
            
            MedicalHistory medPet=new MedicalHistory(true, new Date(), diagnosis,symptoms, pet3, custo1);
            
            System.out.println("Type number of medicines");
            int numberMedicines=in.nextInt();
            
       
            for(int i=0;i<numberMedicines;i++){
                System.out.println("Type name of the medicine");
                String nameMedicine=in.nextLine();
                System.out.println("Type dose of the medicine");
                double doseMedicine=in.nextDouble();
                System.out.println("Type cost per dose of the medicine");
                int costMedicine=in.nextInt();
                System.out.println("Type frecuency of the medicine");
                String frecuencyMedicine=in.nextLine();
                medPet.getMedicines().add(new Medicine(nameMedicine,doseMedicine,costMedicine,frecuencyMedicine));
            
            }
            
            pet3.getHistories().add(medPet);
            vet.getRooms()[available]=new MiniRoom(true,medPet);
            vet.getRooms()[available].setAvailable(false);
            System.out.println("The pet is hospitalized");
             System.out.println();
            }
            else{
            System.out.println("There are no rooms available");
            }
        
/*Test
            int available=vet.availability();
            
            if(available!=-1){
            Pet pet4=new Pet ("sol3",'p',1,1,"","hollys");

            Customer custo2=new Customer("hollys","address1",0000,00000);
            
            if(vet.validateCustomer("hollys","sol3")==false){
            if(vet.addPet(pet4)==true){System.out.println("pet added");}
            else{
            vet.addCustomer(custo2,pet4);
            System.out.println("user added");
            }}
       
            MedicalHistory medPet1=new MedicalHistory(true, new Date(), "diagnosis","symptoms", pet4, custo2);
            medPet1.getMedicines().add(new Medicine("nameMedicine",12,13,"one a day"));
            pet4.getHistories().add(medPet1);
            vet.getRooms()[available]=new MiniRoom(true,medPet1);
            vet.getRooms()[available].setAvailable(false);
            System.out.println("The pet is hospitalized");
            System.out.println(vet.getRooms()[0].toString());
            System.out.println(vet.getCustomers().toString());
            }
            else{
            System.out.println("There are no rooms available");
            }
            
            */
            
 case 8:   System.out.println("Type pet's name");

           String name2=in.nextLine();

            in.nextLine();
            
            System.out.println("Type customer's name");

           String name3=in.nextLine();

            in.nextLine();
            
            vet.dischargingPet(name3,name2);
            
            System.out.println(vet.dischargingPet(name3,name2));
                
            
            System.out.println(vet.dischargingPet("holly","sol"));
             
            
            
    break;           
            
case 9:System.out.println("Hospitalized pets (Medical Histories)");
        System.out.println(vet.hospitalizedPets());
    break;
            
case 10:System.out.println(vet.hospitalizationCost());
    break;

    
case 11:   System.out.println("Income for open hospitalizations");
           System.out.println(vet.hospitalizationCost());
           System.out.println("Income for closed hospitalizations");
           System.out.println(vet.calculateIncome());
        break;
        
        
default: System.out.println("no valid option ");
    break;
           
}
    }
    
 //preload data
public static void dataV(Veterinary vet){
    
    System.out.println("data data");
    
    
if(vet.validateCustomer("holly","sol")==false){
Pet pet=new Pet ("sol",'p',2,20,"race","holly");

Customer custo=new Customer("holly","address",0000,00000);
vet.addCustomer(custo,pet);
System.out.println("usser added");

 Pet pet1=new Pet ("solo",'p',2,2,"raceQ","holly");
    
 if(vet.addPet(pet1)==true){System.out.println("Pet added");}
 else{System.out.println("Pet already exist");}

MedicalHistory medi=new MedicalHistory(true,new Date(),"","",pet,custo);
pet.getHistories().add(medi);
medi.getMedicines().add(new Medicine("aspirine",3,12000,"one a day"));
vet.getRooms()[5]=new MiniRoom(false,medi);

MedicalHistory medi1=new MedicalHistory(true,new Date(),"","",pet1,custo);
pet1.getHistories().add(medi1);
medi1.getMedicines().add(new Medicine("aspirine",3,12000,"one a day"));
vet.getRooms()[7]=new MiniRoom(false,medi1);
System.out.println(vet.dischargingPet("holly", "solo"));

System.out.println(pet.getHistories().toString()); 
} else{ System.out.println("usser alrady exists");  }     
   
     if(vet.validateCustomer("holly","sol")==false){
Pet pet=new Pet ("sol",'p',2,20,"race","holly");

Customer custo=new Customer("holly","address",0000,00000);
vet.addCustomer(custo,pet);
 
} else{ System.out.println("usser alrady exists");  }  
    System.out.println( vet.getCustomers().toString());
}

}

