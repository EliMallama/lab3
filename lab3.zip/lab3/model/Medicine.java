//class definition
public class Medicine {
    
    private String name="";
    private double dose=0;
    private int doseCost=0;
    private String frecuency="";
//constructor
    public Medicine(String name, double dose, int doseCost, String frecuency) {
        
        this.name=name;
        this.dose=dose;
        this.doseCost=doseCost;
        this.frecuency=frecuency;
        
    }
//getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDose() {
        return dose;
    }

    public void setDose(double dose) {
        this.dose = dose;
    }

    public int getDoseCost() {
        return doseCost;
    }

    public void setDoseCost(int doseCost) {
        this.doseCost = doseCost;
    }

    public String getFrecuency() {
        return frecuency;
    }

    public void setFrecuency(String frecuency) {
        this.frecuency = frecuency;
    }

     //toString
    public String toString() {
        return "Medicine{" + "name=" + name + ", dose=" + dose + ", doseCost=" + doseCost + ", frecuency=" + frecuency + '}';
    }
    
    
}

