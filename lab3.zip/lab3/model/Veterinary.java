import java.util.*;
//class definition
public class Veterinary {
    
  private String name="My little pet";
  private ArrayList<Customer> customers=new ArrayList<>();
  private ArrayList<Pet> pets=new ArrayList<>();
  private ArrayList<MedicalHistory> histories=new ArrayList<>();
  private MiniRoom[] rooms=new MiniRoom[8];
  //constructor
    public Veterinary() {
    }

 //getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(ArrayList<Customer> customers) {
        this.customers = customers;
    }

    public ArrayList<Pet> getPets() {
        return pets;
    }

    public void setPets(ArrayList<Pet> pets) {
        this.pets = pets;
    }

    public ArrayList<MedicalHistory> getHistories() {
        return histories;
    }

    public void setHistories(ArrayList<MedicalHistory> histories) {
        this.histories = histories;
    }

    public MiniRoom[] getRooms() {
        return rooms;
    }

    public void setRooms(MiniRoom[] rooms) {
        this.rooms = rooms;
    }

   //toString 
    public String toString() {
        return "Wellcome to Veterinary " + name;
    }
  
    
    //validate if a customer and a pet exists
  public boolean validateCustomer(String nameC, String nameP){
      
      boolean exist=false;
              
      for(Pet pet:pets){
        if((pet.getName()==nameP) && (pet.getOwnerName()==nameC)){
            exist=true;
        }
      }
      return exist;}
  
  //Add a customer and the pet for the first time
  public void addCustomer(Customer custo, Pet pet){
      
      customers.add(custo);
      pets.add(pet);
      custo.getPets().add(pet);
  }
 
  //add a pet when the customer already exists
  public boolean addPet(Pet pet){
      
      boolean added=false;
      boolean exist=false;
      
      for(Customer custi:customers){
          if(custi.getName()==pet.getOwnerName()){
              for(Pet peti:custi.getPets()){
                  if(peti.getName()==pet.getName()){
                      exist=true;
                  }
              } 
              if(exist==false){
                  custi.getPets().add(pet);
                  pets.add(pet);
                  added=true;
              }
          } 
      }
      return added;
  }
  
  //Return the customer's info
  public String contactInfo(String nameC, String nameP){
      
      Customer custa=null;
      
       
      
      for(Customer custi:customers){
           
          if(custi.getName()==nameC){
             
              for(Pet peti:custi.getPets()){
                  if(peti.getName()==nameP){
                      custa=custi;
                  }
              }
          }
  }
      if(custa!=null){
        return custa.toString();  
      } else {
          return "information is not available";
      }
    
 }
  
  
  //return the room that is occupied by a pet by name. If another pet has the same name it will return its number's room too.
  public String displayRoom(String nameT){
      
      String room="";
      
      for(int i=0;i<rooms.length;i++){
          if(rooms[i]!=null){
            if( rooms[i].getMedicalHistory().getPete().getName()==nameT){
                room+=(i++)+",";
            }
          }
      }
      if(room==""){
          room="pet not founded";
      }
      return room;
  }
  
  
  //Remove a pet when it dies
  public void deletePet(String nameC, String nameP){
  boolean exist=validateCustomer(nameC,nameP);
  Pet pet1=null;
  if(exist==true)
  {
      //remove the pet from de customer list
      for(Customer custi:customers){
      if(custi.getName()==nameC){
           for(Pet peti:custi.getPets()){
               if(peti.getName()==nameP){
                   pet1=peti;
                  
               }
      }
           if(pet1!=null){
           custi.getPets().remove(pet1);
           }
            if(custi.getPets().isEmpty())
                   {
                    custi.setStatus(false);
                   }
      }
      
  }
      //remove the pet from the pets list  
      pets.remove(pet1);
      
     
     
  
  }
}
  
  //inactivate a customer even if the customer has or not one or more pets
  public Customer inactivateCustomer(int idC)
  {
      Customer custo=null;
  for(Customer custi:customers){
       if(custi.getId()==idC){
           custi.setStatus(false);
           custo=custi;
       }
  }
   return custo;
  }
  
  //return the first room available
  public int availability()
  { int available=-1;
  for(int i=0; i<rooms.length;i++)
    {
     if(rooms[i]==null)
    {
       available=i;
       break;
    }
    }
  
  return available;
  }
  
  //return the report about hospitalized pets
  public String hospitalizedPets()
  {
      String report="";
  for(int i=0;i<rooms.length;i++)
  {
      if(rooms[i]!=null){
        report+="Room: "+i+"\n"+rooms[i].getMedicalHistory().toString()+"\n"+"\n";
      }
  }  
  return report;
  }
  
  //return the report about a pet discharged
 public String dischargingPet(String nameC,String nameP){


String discharged="";
 for(Customer custi:customers){
      if(custi.getName()==nameC){
           for(Pet peti:custi.getPets()){
               if(peti.getName()==nameP){
                   for(MedicalHistory his:peti.getHistories()){
                      if(his.getStatus()==true){
                         his.setStatus(false);
                         for(int i=0;i<rooms.length;i++)
                         {
                             if(rooms[i]!=null){
                             if(rooms[i].getMedicalHistory().getPete().getName()==nameP && rooms[i].getMedicalHistory().getCuste().getName()==nameC)
                             {
                             discharged+="Room "+i+":"+rooms[i].getMedicalHistory().toString()+"\n";
                             discharged+=this.hospitalizationCostUnit(i);
                             his.setCost(this.hospitalizationCostUnitIncome(i));
                             histories.add(his);
                             rooms[i]=null;
                             
                             }
                             }
                         }
                         
               }
               }
               
                   
            }

        }
      }
 }
 return discharged;
 }
 
 //hospitalization report about the cost for all rooms
 public String hospitalizationCost()
 { int costes=0;
   String totalCoste="";
     for(int i=0;i<rooms.length;i++)
     {
          if(rooms[i]!=null){
          char type=rooms[i].getMedicalHistory().getPete().getType();
          double weight=rooms[i].getMedicalHistory().getPete().getWeight();
          int costeMedicine=0;
          for(Medicine med:rooms[i].getMedicalHistory().getMedicines()){
          costeMedicine+=(med.getDoseCost()*med.getDose());
          }
          if(weight>=1 && weight<=3){
              if(type=='c'){costes+=10000;}
              if(type=='p'){costes+=15000;}
              if(type=='a'){costes+=10000;}
              if(type=='o'){costes+=10000;}
          
          }
          if(weight>=3.1 && weight<=10){
              if(type=='c'){costes+=12000;}
              if(type=='p'){costes+=17000;}
              if(type=='a'){costes+=12000;}
              if(type=='o'){costes+=17000;}
          
          
          }
          if(weight>=10.1 && weight<=20){
              if(type=='c'){costes+=15000;}
              if(type=='p'){costes+=20000;}
              if(type=='a'){costes+=20000;}
              if(type=='o'){costes+=30000;}
          }
          if(weight>20){
              
              if(type=='c'){costes+=20000;}
              if(type=='p'){costes+=25000;}
              if(type=='a'){costes+=25000;}
              if(type=='o'){costes+=33000;}
          }
          
          
          totalCoste+="Hospitalization cost for room number "+i+"="+(costes+costeMedicine)+"\n"+"\n";
          }
     }
          return totalCoste;
     }
 
 //hospitalization report about the cost for a specific room
 public String hospitalizationCostUnit(int i)
 { int costes=0;
   String totalCoste="";
    
          if(rooms[i]!=null){
          char type=rooms[i].getMedicalHistory().getPete().getType();
          double weight=rooms[i].getMedicalHistory().getPete().getWeight();
          int costeMedicine=0;
          for(Medicine med:rooms[i].getMedicalHistory().getMedicines()){
          costeMedicine+=(med.getDoseCost()*med.getDose());
          }
          if(weight>=1 && weight<=3){
              if(type=='c'){costes+=10000;}
              if(type=='p'){costes+=15000;}
              if(type=='a'){costes+=10000;}
              if(type=='o'){costes+=10000;}
          
          }
          if(weight>=3.1 && weight<=10){
              if(type=='c'){costes+=12000;}
              if(type=='p'){costes+=17000;}
              if(type=='a'){costes+=12000;}
              if(type=='o'){costes+=17000;}
          
          
          }
          if(weight>=10.1 && weight<=20){
              if(type=='c'){costes+=15000;}
              if(type=='p'){costes+=20000;}
              if(type=='a'){costes+=20000;}
              if(type=='o'){costes+=30000;}
          }
          if(weight>20){
              
              if(type=='c'){costes+=20000;}
              if(type=='p'){costes+=25000;}
              if(type=='a'){costes+=25000;}
              if(type=='o'){costes+=33000;}
          }
          
          
          totalCoste+="Hospitalization cost for room number "+i+"="+(costes+costeMedicine)+"\n"+"\n";
          }
     
          return totalCoste;
     }

 //return the cost for a hospitalization
 public int hospitalizationCostUnitIncome(int i)
 { 
          int totalCoste=0;
          int costes=0;
          int costeMedicine=0;
          char type=rooms[i].getMedicalHistory().getPete().getType();
          double weight=rooms[i].getMedicalHistory().getPete().getWeight();
          
          for(Medicine med:rooms[i].getMedicalHistory().getMedicines()){
          costeMedicine+=(med.getDoseCost()*med.getDose());
          }
          if(weight>=1 && weight<=3){
              if(type=='c'){costes+=10000;}
              if(type=='p'){costes+=15000;}
              if(type=='a'){costes+=10000;}
              if(type=='o'){costes+=10000;}
          
          }
          if(weight>=3.1 && weight<=10){
              if(type=='c'){costes+=12000;}
              if(type=='p'){costes+=17000;}
              if(type=='a'){costes+=12000;}
              if(type=='o'){costes+=17000;}
          
          
          }
          if(weight>=10.1 && weight<=20){
              if(type=='c'){costes+=15000;}
              if(type=='p'){costes+=20000;}
              if(type=='a'){costes+=20000;}
              if(type=='o'){costes+=30000;}
          }
          if(weight>20){
              
              if(type=='c'){costes+=20000;}
              if(type=='p'){costes+=25000;}
              if(type=='a'){costes+=25000;}
              if(type=='o'){costes+=33000;}
          }
          
          
          totalCoste+=(costes+costeMedicine);
          
     
          return totalCoste;
     }
 
 //return the total income for all closed hospitalizations
 public int calculateIncome()
 {
     
int totalIncome=0;
 for(MedicalHistory med:histories){
 totalIncome+=med.getCost();
 }
 return totalIncome;
}

}
