import java.util.ArrayList;



//class definition
public class Pet {
    
    private String name="";
    private char type='h';
    private int age=0;
    private double weight=0;
    private String race="";
    private String ownerName="";
    private ArrayList<MedicalHistory> histories=new ArrayList<MedicalHistory>();
//constructor
    public Pet(String name, char type, int age, double weight, String race, String ownerName) {
        
        this.name=name;
        this.type=type;
        this.age=age;
        this.weight=weight;
        this.race=race;
        this.ownerName=ownerName;       
    }
//getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public ArrayList<MedicalHistory> getHistories() {
        return histories;
    }

    public void setHistories(ArrayList<MedicalHistory> histories) {
        this.histories = histories;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    //toString
    public String toString() {
        return "Pet{" + "name=" + name + ", type=" + type + ", age=" + age + ", weight=" + weight + ", race=" + race + ", ownerName=" + ownerName + ", histories=" + histories + '}';
    }
    

   
    
    
}