import java.util.ArrayList;
import java.util.Date;
//class definition
public class MedicalHistory {
    
    private boolean status=false;
    private Date admissionDate=null;
    private String diagnosis="";
    private String symptoms="";
    private ArrayList<Medicine> medicines=new ArrayList<Medicine>();
    private Pet pete=null;
    private Customer custe=null;
    private int cost=0;

   //constructor
    public MedicalHistory(boolean status, Date admissionDate, String diagnosis, String symptoms, Pet pete, Customer custe) {
    
        this.status=status;
        this.admissionDate=admissionDate;
        this.diagnosis=diagnosis;
        this.symptoms=symptoms;
        this.pete=pete;
        this.custe=custe;
    }
//getters and setters
    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Date getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(Date admissionDate) {
        this.admissionDate = admissionDate;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public ArrayList<Medicine> getMedicines() {
        return medicines;
    }

    public void setMedicines(ArrayList<Medicine> medicines) {
        this.medicines = medicines;
    }

    public Pet getPete() {
        return pete;
    }

    public void setPete(Pet pete) {
        this.pete = pete;
    }

    public Customer getCuste() {
        return custe;
    }

    public void setCuste(Customer custe) {
        this.custe = custe;
    }

     public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }
    
    
     //toString
    public String toString() {
        return "MedicalHistory{" + "status=" + status + ", admissionDate=" + admissionDate + ", diagnosis=" + diagnosis + ", symptoms=" + symptoms + ", medicines=" + medicines + '}';
    }

    
    
    
    
      
             
    }