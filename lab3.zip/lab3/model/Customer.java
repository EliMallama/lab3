
import java.util.ArrayList;
//class definition
public class Customer {
  
  private String name="";
  private String address="";
  private int phone=0;
  private int id=0;
  private ArrayList<Pet> pets=new ArrayList<Pet>();
  private boolean status=true;

  
//constructor
    public Customer(String name, String address, int phone, int id) {
        
        this.name=name;
        this.address=address;
        this.phone=phone;
        this.id=id;
    }

   //getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Pet> getPets() {
        return pets;
    }

    public void setPets(ArrayList<Pet> pets) {
        this.pets = pets;
    }

      public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

 //toString
    public String toString() {
        return "Customer{" + "name=" + name + ", address=" + address + ", phone=" + phone + ", id=" + id + ", pets=" + pets + ", status=" + status + '}';
    }
    
   
    
   

    
    
}
