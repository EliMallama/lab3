//class definition
public class MiniRoom {
    
    private boolean available=true;
    private MedicalHistory medicalHistory=null;
//constructor
    public MiniRoom(boolean ava,MedicalHistory his) {
        available=ava;
        medicalHistory=his;
    }
//getters and setters
    public boolean getAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public MedicalHistory getMedicalHistory() {
        return medicalHistory;
    }

    public void setMedicalHistory(MedicalHistory medicalHistory) {
        this.medicalHistory = medicalHistory;
    }

  //toString
    public String toString() {
        return "MiniRoom{" + "available=" + available + ", medicalHistory=" + medicalHistory + '}';
    }

   
   
   
}